package com.example.chess.Game_logic

class Pawn(
    override val color: String?,
    override var coordinate: Array<Int>,
    override val name: String = "pawn"
): Piece {

    var canPassant = false  //Чи можна взяти пішку на проході

    override fun isMove(cord: Array<Int>): Boolean {
        return true
    }


}
