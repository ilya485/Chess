package com.example.chess

import android.net.wifi.p2p.WifiP2pManager
import com.example.chess.UI.MainActivity

class BroadcastReceiver(
    private val manager: WifiP2pManager,
    private val channel: WifiP2pManager.Channel,
    private val activity: MainActivity
) : BroadcastReceiver()