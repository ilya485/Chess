package com.example.chess.UI

import android.os.Bundle
import android.os.Handler
import android.support.v4.app.Fragment
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import com.example.chess.R
import java.lang.String
import java.util.*


class WatchFragment : Fragment() {

    private var seconds:Long = 0
    private var seconds1:Long = 0
    private var seconds2:Long = 0
    private val startTime1:Long = 0
    private val startTime2:Long = 0
    private var add = 0
    private var tapCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val layout: View = inflater.inflate(R.layout.fragment_watch, container, false)
        return inflater.inflate(R.layout.fragment_watch, container, false)

    }


    override fun onStart() {
        super.onStart()

        val view = view

        if (view != null) {
            //runTimer()
            val textMin = view.findViewById(R.id.editMinutes) as TextView
            val textSec = view.findViewById(R.id.editSecond) as TextView
            val textAdd = view.findViewById(R.id.editAdditionally) as TextView

            val timeV1 = view.findViewById(R.id.time1) as TextView
            val timeV2 = view.findViewById(R.id.time2) as TextView
            var timeV = timeV2

            val But = view.findViewById(R.id.but) as ImageButton
            But.setOnClickListener {

                //var startMoveTime:Long = 0
                if (tapCount == 0){
                    textMin.visibility=View.INVISIBLE
                    textSec.visibility=View.INVISIBLE
                    textAdd.visibility=View.INVISIBLE
                    textMin.setBackgroundResource(R.color.light)
                    textSec.setBackgroundResource(R.color.light)
                    textAdd.setBackgroundResource(R.color.light)
                    timeV1.setTextColor(resources.getColor(R.color.dark))
                    timeV2.setTextColor(resources.getColor(R.color.dark))
                    timeV1.setTextSize(
                        TypedValue.COMPLEX_UNIT_PX,
                        resources.getDimension(R.dimen.watchSize))
                    seconds1 = textMin.text.toString().toLong() * 60 + textSec.text.toString().toInt()
                    seconds2 = seconds1
                    seconds = seconds1
                    timeV1.text=String.format(
                        Locale.getDefault(),
                        "%02d:%02d",  seconds % 3600 / 60, seconds % 60
                    )
                    timeV2.text=String.format(
                            Locale.getDefault(),
                    "%02d:%02d",  seconds % 3600 / 60, seconds % 60
                    )
                    add = textAdd.text.toString().toInt()
                    timeV1.rotation = 180F
                    //var timeV = timeV2
                    val handler = Handler()
                    //val startMoveTime = System.currentTimeMillis()
                    handler.post(object : Runnable {
                        override fun run() {
                            val time_V = timeV
                            val timeNow=System.currentTimeMillis()
                                //seconds -= (timeNow - startMoveTime) / 1000
                            val minutes = seconds % 3600 / 60
                            val secs = seconds % 60
                            val time = String.format(
                                Locale.getDefault(),
                                "%02d:%02d",  minutes, secs
                            )
                            seconds--
                            time_V.text = time
                            handler.postDelayed(this, 1000)
                        }
                    })
                } else if (tapCount%2==1){
                    timeV = timeV1
                    seconds1 = seconds + add
                    seconds = seconds2
                    //startMoveTime=startTime1
                    But.setBackgroundResource(R.color.dark)
                    textMin.setBackgroundResource(R.color.dark)
                    textSec.setBackgroundResource(R.color.dark)
                    textAdd.setBackgroundResource(R.color.dark)
                    timeV1.setTextColor(resources.getColor(R.color.light))
                    timeV2.setTextColor(resources.getColor(R.color.light))
                }else {
                    timeV = timeV2
                    seconds2 = seconds + add
                    seconds = seconds1
                    //startMoveTime=startTime1
                    But.setBackgroundResource(R.color.light)
                    textMin.setBackgroundResource(R.color.light)
                    textSec.setBackgroundResource(R.color.light)
                    textAdd.setBackgroundResource(R.color.light)
                    timeV1.setTextColor(resources.getColor(R.color.dark))
                    timeV2.setTextColor(resources.getColor(R.color.dark))
                }
                tapCount++

            // TODO Restart button
            // TODO End


            }
        }
    }

    private fun runTimer() {
        //val timeView = findViewById(R.id.time_view) as TextView

    }
}