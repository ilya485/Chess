package com.example.chess.Game_logic

import android.widget.ImageView

open class Board() {
    public var boardPiece = arrayOfNulls<Array<Piece>>(10)
    var isCheck = false
    var isCheckmate = false
    var isStalemate = false
    var kingBlackPos = arrayOf(0, 4)
    var kingWhitePos = arrayOf(7, 4)
    var passant: Pawn? = null

    constructor(a: Int) : this() {

        boardPiece[0] = arrayOf(
            Rock("black", arrayOf(0, 0)),
            Knight("black", arrayOf(0, 1)),
            Bishop("black", arrayOf(0, 2)),
            Queen("black", arrayOf(0, 3)),
            King("black", arrayOf(0, 4)),
            Bishop("black", arrayOf(0, 5)),
            Knight("black", arrayOf(0, 6)),
            Rock("black", arrayOf(0, 7))
        )
        boardPiece[1] = Array(8, { i -> Pawn("black", arrayOf(0, i)) })


        boardPiece[7] = arrayOf(
            Rock("white", arrayOf(7, 0)),
            Knight("white", arrayOf(7, 1)),
            Bishop("white", arrayOf(7, 2)),
            Queen("white", arrayOf(7, 3)),
            King("white", arrayOf(7, 4)),
            Bishop("white", arrayOf(7, 5)),
            Knight("white", arrayOf(7, 6)),
            Rock("white", arrayOf(7, 7))
        )
        boardPiece[6] = Array(8, { i -> Pawn("black", arrayOf(6, i)) })

    }


    fun moveRule(coord: Array<Array<Int>>): Boolean {
        return true
        //return boardPiece[coord[0][0]][coord[0][1]]?.isMove(coord[1][0]][coord[1][1])
    }

    fun moveWithoutRule(coord: Array<Array<Int>>) {

    }

}