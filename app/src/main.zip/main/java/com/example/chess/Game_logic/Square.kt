package com.example.chess.Game_logic

class Square {
}