package com.example.chess.Game_logic

class Rock(
    override val color: String?,
    override var coordinate: Array<Int>,
    override val name: String = "rock"
): Piece {

    override fun isMove(cord: Array<Int>): Boolean {
        return true
    }


}