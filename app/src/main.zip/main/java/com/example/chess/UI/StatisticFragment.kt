package com.example.chess.UI

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import android.widget.SimpleCursorAdapter
import android.widget.Toast
import com.example.chess.DataBaseHelper
import com.example.chess.R


class StatisticFragment : Fragment() {

    //private val db: SQLiteDatabase? = null
    private var cursor: Cursor? = null
    // TODO: Rename and change types of parameters

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_statistic, container, false)
    }

    override fun onStart() {
        super.onStart()
        val view = view
        val databaseHelper: SQLiteOpenHelper = DataBaseHelper(activity)

        if (view !== null) {
            val listGames: ListView = view.findViewById(R.id.list_games) as ListView
            val db = databaseHelper.readableDatabase

            try {

                cursor = db.query(
                    "GAME", arrayOf("_id", "NOTE", "WINNER"),
                    null, null, null, null, null
                )
                val noteValues = ContentValues()
                noteValues.put("NOTE", "e2:e4; e7:e5; a2:a4; a7:a5")
                noteValues.put("WINNER", "White")
                db.insert("GAME", null, noteValues)
                val listAdapter = SimpleCursorAdapter(
                    activity,
                    android.R.layout.simple_list_item_1,
                    cursor, arrayOf("NOTE"), intArrayOf(android.R.id.text1),
                    0
                )
                listGames.setAdapter(listAdapter)
            } catch (e: SQLiteException) {
                val toast: Toast = Toast.makeText(activity, "Database unavailable", Toast.LENGTH_SHORT)
                toast.show()
            }
        }

    }

}